<?php require('connection.php');
    session_start();
    $user_id = $_SESSION['user_id'];
    if(isset($_POST["c_id"])){
        $c_id = $_POST["c_id"];
        $query = "UPDATE cart set complete_order = true where c_id = '$c_id';";
        $reasult = mysqli_query($connection,$query);
        if($connection->query($query) ==TRUE){
            echo "<script> alert('The order has been completed'); </script>";
        }           
    }
    else
    {
        echo $connection->error;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order checking page</title>
    <link rel="stylesheet" type="text/css" href="css/vendor_fetch.css">
    <style>
        button{
            background-color: #c61492;
            margin-top: 25px;
            padding: 17px 8px;
            border-radius: 0 !important;
            font-weight: 600;
            font-size: 14px;
            line-height: 17px;
            text-align: center;
            letter-spacing: 2.4px;
            text-transform: uppercase;
            width: auto;
            color: #ffffff;  
        }
    </style>
</head>
<body>

    <div id="top">
        <h1 id="heading">Customer Orders</h1>
        <a href="vendor.php"> <img id="go_back" src="image/goback.png" ></a>
    </div>
    <div class="product-container">
            <?php 
            $myproduct = mysqli_query($connection,"SELECT * from cart where vendor_id = $user_id and buy = false and complete_order=false;"); // HEre we are first comparint the user id of the logged in user with user_ids and cart
            //so all data in cart which has user id of customer will be in my product
                if (mysqli_num_rows($myproduct)> 0) {
                    while($row = mysqli_fetch_array($myproduct)){ 
                        $productofvendor = $row['p_id']; // this will put all product which the user has put in as cart inside $productofuser
                        $final_productofvendor = mysqli_query($connection,"SELECT * from product where p_id = $productofvendor;"); // this will connect productid of cart with user as same as user with productid of product
                        while($final_row = mysqli_fetch_array($final_productofvendor)){ // now we can access everything from product table 

                            $customer_id = $row['customer_id'];
                            $user_info = mysqli_query($connection,"SELECT * from user where user_id = $customer_id;");
                            while($final_final_row = mysqli_fetch_array($user_info)){
                        ?>
                                <div class="product">
                                    <img src="<?php echo $final_row['image'];?>" alt="Product 1">
                                    <div class="details">
                                        <h2><?php echo $final_row['name'];?></h2>
                                        <div class="price-category">
                                            <div class="price">Price: <?php echo $final_row['price'];?></div>
                                            <div class="category"><?php echo $final_row['category'];?></div>
                                        </div>
                                        <div class="description">
                                            <p>Name: <?php echo $final_final_row['first_name'];?> <?php echo $final_final_row['last_name'];?></p>
                                            <p>Phone Number: <?php echo $final_final_row['phone'];?></p>
                                            <p>Address: <?php echo $final_final_row['address'];?></p>
                                        </div>
                                        <div class="actions">
                                            <form action="vendor_order.php" method="post">
                                                <input type="text" name="c_id" value="<?php echo $row['c_id'] ?>" hidden>
                                                <button>Complete Order</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                        
                            
                        <?php }
                            }
                    }
                }
                else{
                    echo "<h1>There is no order</h1>";
                } ?>

    </div>

    
</body>
</html>
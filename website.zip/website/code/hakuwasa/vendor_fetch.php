<?php require('connection.php');
    //extracting user id fron login page
    session_start();
    $vendor_id = $_SESSION['user_id'];

    $result = mysqli_query($connection , "SELECT * FROM product WHERE vendor_id='$vendor_id' ");

?>
<!DOCTYPE html>
<html>
<head>
	<title>Product Catalog</title>
	<link rel="stylesheet" type="text/css" href="css/vendor_fetch.css">
</head>
<body>
    <div id="top">
    <h1 id="heading">My products</h1>
    <a href="vendor.php"> <img id="go_back" src="image/goback.png" ></a>
    </div>
	<div class="product-container">
    <?php if (mysqli_num_rows($result)> 0) {?>
    <?php while($row = mysqli_fetch_array($result)){?> 
            <div class="product">
                <img src="<?php echo $row['image'];?>" alt="Product 1">
                <div class="details">
                    <h2><?php echo $row['name'];?></h2>
                    <div class="price-category">
                        <div class="price">Price: <?php echo $row['price'];?></div>
                        <div class="category"><?php echo $row['category'];?></div>
                    </div>
                    <div class="description">
                        <p><?php echo $row['description'];?></p>
                    </div>
                    <div class="actions">
                        <a class="link" style="text-decoration:none" href = "vendor_edit.php?id=<?php echo $row['p_id']; ?>">Edit</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <a class="link" style="text-decoration:none" href = "vendor_delete.php?id=<?php echo $row['p_id']; ?>">Delete</a>
                    </div>
                </div>
            </div>
        <?php } ?>  
    <?php
    } 
    else{
        echo "No data";
    }
    ?>
	</div>

</body>
</html>

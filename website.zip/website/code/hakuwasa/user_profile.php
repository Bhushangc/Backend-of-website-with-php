<?php require('connection.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User profile</title>
    <link rel="stylesheet" href="css/vendor.css">



</head>
<body>
    <?php
    //extracting user id fron login page
    session_start();
    $user_id = $_SESSION['user_id'];


    //collecting data from sql
    $result = mysqli_query($connection , "SELECT * FROM user WHERE user_id='$user_id'");
    $row = mysqli_fetch_array($result);
    $username = $row['username'];
    $phone = $row['phone'];
    $first_name = $row['first_name'];
    $last_name = $row['last_name'];
    $address = $row['address'];
    ?>
    <div>
    </div>
     <div id="profile-box">

        <div class="left">
            <h1>Profile</h1>
            <p class="label">User Name</p>
            <p class="label">First Name</p>
            <p class="label">Last Name</p>
            <p class="label">Phone</p>
            <p class="label">Address</p>

        </div>

        <div class="right">
            <p class="text"> <?php echo $username; ?></p>
            <p class="text"><?php echo $first_name;?> </p>
            <p class="text"><?php echo $last_name; ?></p>
            <p class="text"><?php echo $phone; ?></p>
            <p class="text"><?php echo $address; ?></p>
        </div>
        <div class="button-container">
            <a class="link" href="customer_history.php"> History </a>&nbsp; &nbsp;  
            <a class="link" href="home.php"> Go Back </a>    
        </div>

        
        
    </div>
</body>
</html>
<?php require('connection.php');
    if(isset($_POST["c_id"])){
            $c_id = $_POST["c_id"];
            $query = "Insert into customer_order values('','$c_id');";
            $reasult = mysqli_query($connection,$query);
            $query2 = "UPDATE cart set buy = false where c_id = '$c_id';";
            $reasult2 = mysqli_query($connection,$query2);
            if($connection->query($query2) ==TRUE){
                echo "<script> alert('The order has been placed you will be contacted by our vendors'); </script>";
                 
            }  
            header ('Location:cart.php');         
        }
        else
        {
            echo $connection->error;
        }
        
?>
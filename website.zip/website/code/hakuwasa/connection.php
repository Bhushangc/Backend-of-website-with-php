<?php
    $server = 'localhost'; // this is currently our server
    $username = 'root'; 
    $password = '';
    $db = 'haku_wasa'; 

    $connection  = mysqli_connect($server, $username, $password, $db); 
?>
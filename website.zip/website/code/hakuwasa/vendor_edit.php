<?php require('connection.php');
if (isset($_GET["id"])){
$p_id =$_GET["id"];
$result = mysqli_query($connection,"SELECT * from product where p_id = $p_id;");
$row = mysqli_fetch_array($result);
$name = $row['name'];
$price = $row['price'];
$category = $row['category'];
$description = $row['description'];
$image = $row['image'];
$vendor_id = $row['vendor_id'];
}
if(isset($_POST["submit"])){
    $p_id = $_POST['p_id'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $category = $_POST['category'];
    $description = $_POST['description'];
    $query = "UPDATE product SET name = '$name', category = '$category', price = '$price', description = '$description' where p_id = '$p_id';";
    if ($connection->query($query) == TRUE) {
        header('Location: vendor_fetch.php');
    } else {
        echo $connection->error;
    }
}
?>
<img src="<?php echo $image;?>" height="400px" width="400px"> <br> <br> <br>
    <form action="vendor_edit.php" method="post" ">
        <input type="text" name="p_id" value="<?php echo $p_id ?>" hidden>

        <label for="name">Product name:</label>
        <input type="text" name="name" value="<?php echo $name ?>" placeholder="Product name" required> <br>

        <label for="price">Price:</label>
        <input type="number" name="price" value="<?php echo $price ?>" placeholder="Price" required> <br>

        <label for="category">Category:</label>
        <input type="radio" name="category" value="men" checked> Men
        <input type="radio" name="category" value="women"> Women
        <input type="radio" name="category" value="kids"> Kids
        <input type="radio" name="category" value="accessories"> Accessories<br>
        <label for="description">Description of product:</label><br>
        <textarea name="description" cols="50" rows="10" placeholder="Description of product" required><?php echo $description ?></textarea>
        <br>

        <input type="submit" name="submit" value="Update Product">
    </form>

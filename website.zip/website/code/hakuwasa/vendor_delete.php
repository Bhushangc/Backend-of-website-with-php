<?php require('connection.php');
$p_id =$_GET["id"];
$query = "DELETE FROM product where p_id = '$p_id'";
if ($connection->query($query) ==TRUE) {
    header ('Location:vendor_fetch.php');
    
}
else
{
    echo $connection->error;
}

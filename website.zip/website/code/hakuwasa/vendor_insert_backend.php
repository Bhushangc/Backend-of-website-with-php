<?php require('connection.php');
    if(isset($_POST["submit"])){
        $name = $_POST["name"];
        $price = $_POST["price"];
        $category = $_POST["category"];
        $description = $_POST["description"];
        $image = $_FILES["image"]['name'];
        session_start();
        $user_id = $_SESSION['user_id'];

        $query = "Insert into product values('','$name', '$price', '$category','$description','$image','$user_id');";
        $reasult = mysqli_query($connection,$query);
        if($reasult){
            move_uploaded_file($_FILES['image']['tmp_name'], "$image");
            header ('Location:vendor.php');
        }
    }
   
?>
<?php require('connection.php');
    session_start();
    $user_id = $_SESSION['user_id'];
    if(isset($_POST["customer_id"])){
        $customer_id = $_POST["customer_id"];
        $vendor_id = $_POST["vendor_id"];
        $p_id = $_POST["p_id"];
        $query = "Insert into cart values('','$customer_id', '$vendor_id', '$p_id',true,false);";
        if ($connection->query($query) == TRUE) {
            echo "<script> alert('The order has been added to cart'); </script>";
        } else {
            echo $connection->error;
        }
        
    }
    if(isset($_POST["c_id"])){
        $c_id = $_POST["c_id"];
        $query = "Insert into customer_order values('','$c_id');";
        $reasult = mysqli_query($connection,$query);
        $query2 = "UPDATE cart set buy = false where c_id = '$c_id';";
        $reasult2 = mysqli_query($connection,$query2);
        if($connection->query($query2) ==TRUE){
            echo "<script> alert('The order has been placed you will be contacted by our vendors'); </script>";
        }           
    }
    else
    {
        echo $connection->error;
    }
    $result2 = mysqli_query($connection , "SELECT * FROM user WHERE user_id='$user_id'");
    $row = mysqli_fetch_array($result2);
    $username = $row['username'];
    $phone = $row['phone'];
    $first_name = $row['first_name'];
    $last_name = $row['last_name'];
    $address = $row['address'];
?>
    
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/vendor_fetch.css">
    <title>Cart</title>
    <style>
        button{
            background-color: #c61492;
            padding: 15px 28px;
            border-radius: 0 !important;
            font-weight: 600;
            font-size: 14px;
            line-height: 17px;
            text-align: center;
            letter-spacing: 2.4px;
            text-transform: uppercase;
            width: auto;
            color: #ffffff;  
        }
    </style>
    <style>

        .contains-product{
            display: flex;
            justify-content: left;
            flex-wrap: wrap;
        }
        .contains{
            margin-left: 190px;
            width: 1460px;
            margin-bottom:100px;
            
        }
        .pro-img img{
            width: 100%;
            height: 430px;
            object-fit: cover;
            }
            .pro-img{
                width: 313px;
            }
        .imageshowing{
            margin-left: 10px;
            margin-right: 10px;
            margin-bottom:20px;
            margin-top:20px;
        }
        .pro-text p{
            color: #1c1b1b;
            text-decoration: none;
            font-weight: 600;
            font-size: 16px;
            line-height: 22px;
        }
        .pro-text span{
            font-weight: 400;
            font-size: 16px;
            line-height: 19px;
            color: #1c1b1b;
            font-family: "Rubik",sans-serif;
        }
    </style>
    <link rel="stylesheet" href="css/home.css">
    <!-- fontawesome -->
    <link href="{{asset('css/font-awesome-all.css')}}" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,300;0,400;0,600;0,700;0,800;0,900;1,300;1,400;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="fix-size">
            <div class="main">
                <section>
                <div class="oppsilder">
                    <div class="opp_slider_header">
                    <i class="fas fa-phone-alt"></i>
                    <span> Toll Free! <a href="tel:+977-9808692427">+977-9808692427</a></span>
                    </div>
                    <div class="opp_slider_photo">
                    <i class="fas fa-user-alt"></i>
                    <span> <a href="user_profile.php"><?php echo $username?></a> |</span>
                    <span> <a href="logout.php">Logout</a></span>
                    </div>
                </div>
                
                </section>
            </div>
        </div>
        <div class="main-header-border">
            <div class="main">
                <div class="main-header">
                <div class="main-logo">
                        <a href="home.php"> <img src="image/logo.png" alt=""></a>
                    </div>
                    <div class="main-menu">
                        <ul class="header-menuli">
                            <li><a href="women.php">Women Dress</a> </li>
                            <li><a href="men.php">Men Dress</a></li>
                            <li><a href="kids.php">Kids Dress</a></li>
                            <li><a href="accessories.php">Accessories</a></li>
                        </ul>
                    </div>
                    <div class="main-menuicon">
                        <a href="cart.php"><i class="fas fa-cart-plus"></i></a>
                    </div>
                </div>
            </div>


    <div class="details-submenu">
        <div class="details-submenu-inner">
            <div id="details-submenu-inner-h5" >Home / My Cart</div>
            </div>
    </div>













    <div class="product-container">
        <?php 
        $myproduct = mysqli_query($connection,"SELECT * from cart where customer_id = $user_id and buy = true;"); // HEre we are first comparint the user id of the logged in user with user_ids and cart
        //so all data in cart which has user id of customer will be in my product
            if (mysqli_num_rows($myproduct)> 0) {
                while($row = mysqli_fetch_array($myproduct)){ 
                    $productofuser = $row['p_id']; // this will put all product which the user has put in as cart inside $productofuser
                    $final_productofuser = mysqli_query($connection,"SELECT * from product where p_id = $productofuser;"); // this will connect productid of cart with user as same as user with productid of product
                    while($final_row = mysqli_fetch_array($final_productofuser)){ // now we can access everything from product table ?>
                        
                        <div class="product">
                            <img src="<?php echo $final_row['image'];?>" alt="Product 1">
                            <div class="details">
                                <h2><?php echo $final_row['name'];?></h2>
                                <div class="price-category">
                                    <div class="price">Price: <?php echo $final_row['price'];?></div>
                                    <div class="category"><?php echo $final_row['category'];?></div>
                                </div>
                                <div class="description">
                                    <p><?php echo $final_row['description'];?></p>
                                </div>
                                <div class="actions">
                                    <form action="cart.php" method="post">
                                        <input type="text" name="c_id" value="<?php echo $row['c_id'] ?>" hidden>
                                        <button>Buy</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    
                        
                    <?php }
                }
             }
             else{
                echo "<h1>Your cart is empty</h1>";
            } ?>

    </div>












    <div class="main-fotter">
           <div class="footer">
            <div class="footer-logo">
                <div class="footer-image">
                    <img src="image/logo.png" alt="">
                </div>
                <div class="footer-detals">
                 <address class="footer-adderess">
                 <i class="fas fa-home"></i>
                 <span>suryabinayak bhaktapur</span>
                 </address>
                 <address class="footer-adderess">
                 <i class="fas fa-phone-alt"></i>
                 <span>+977-980869242</span>
                 </address>   
                 <address class="footer-adderess">
                 <i class="fas fa-envelope-open-text"></i>
                 <span>info@hakuwasa.com</span>
                 </address>   
                </div>
                <div class="footer-social">
                    <span>FOLLOW US:</span>
                    <i class="fab fa-facebook"></i>
                    <i class="fab fa-instagram-square"></i>
                    <i class="fab fa-twitter-square"></i>
                    <i class="fab fa-youtube"></i>
                </div>
            </div>
            <div class="myaccount">
                <div class="footer-user-link">
                    <p>MY ACCOUNT</p>
                    <div class="footer-text">
                    <account><a href="user_profile.php">My Account</a></account>
                    <account><a href="customer_history.php">Order History</a></account>
                    </div>
                    
                </div>
            </div>
            <div class="myaccount">
                <div class="footer-user-link">
                    <p>Our Policies</p>
                    <div class="footer-text">
                    <account><a href="return_policy.php">Return Policy</a></account>
                    <account><a href="shipping_policy.php">Shipping Policy</a></account>
                    </div>
                    
                </div>
            </div>
            <div class="myaccount">
                <div class="footer-user-link">
                    <p>Working Hours</p>
                    <div class="footer-text">
                    <account>Monday - Saturaday</account>
                    <account>11:00AM to 06:00pm</account>
                    </div>
                    
                </div>
            </div>

           </div> 
           <p>This is a website made for college project and is not to be used commercially</p>
        </div>    
    

 
    
</body>
</html>